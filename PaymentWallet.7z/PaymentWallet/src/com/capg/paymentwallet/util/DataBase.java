package com.capg.paymentwallet.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class DataBase {
	
	private static List<BigInteger> phnDetails = new ArrayList<>();
	static {
		
		phnDetails.add(new BigInteger("8978144947"));
		phnDetails.add(new BigInteger("9989530018"));
		phnDetails.add(new BigInteger("7569550009"));
		phnDetails.add(new BigInteger("8106792387"));
		phnDetails.add(new BigInteger("9553373417"));
	}
	
	public static List<BigInteger> getPhoneDetails(){
		return phnDetails;
	}
	

}
