package com.capg.paymentwallet.test;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class AccountServiceImplTest {

	static IAccountService service = null;
	static CustomerBean customerBean = null;
	static AccountBean accountBean = null;

	@BeforeClass
	public static void createInstance() {
		service = new AccountServiceImpl();
		customerBean = new CustomerBean();
		accountBean = new AccountBean();
	}

	@Test(expected = Exception.class)
	public void testForValidNameForLength() throws Exception {
		customerBean.setName("vig");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}
	@Test(expected = Exception.class)
	public void testForValidNameForNull() throws Exception {
		customerBean.setName(null);
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}
	

	@Test(expected = Exception.class)
	public void testForValidAge() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
		customerBean.setAge(12);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}
	
	
	@Test(expected = Exception.class)
	public void testForValidPhnNoForLength() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("56567"));
		customerBean.setEmailId("priyajoseph@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result=service.createAccount(accountBean);
		assertFalse(result);
		
	}
	
	@Test(expected = Exception.class)
	public void testForValidEmail1() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("fghg");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}
	@Test(expected =Exception.class)
	public void testForValidEmailForNull() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId(null);
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
	}
	@Test(expected =Exception.class)
	public void testForValidPanNoForNull() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId(null);
		customerBean.setAge(21);
		customerBean.setPanNo(null);
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
	}
	@Test(expected =Exception.class)
	public void testForValidPanNoForLength() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId(null);
		customerBean.setAge(21);
		customerBean.setPanNo("abcde123");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
	}
	
	@Test(expected = Exception.class)
	public void testForValidBalanceForNegative() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("fghg@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(-100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}
	@Test(expected = Exception.class)
	public void testForValidBalanceForZero() throws Exception {
		customerBean.setName("vidya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("fghg@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(0);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertFalse(result);
		
	}

	
	@Test
	public void testForValid() throws Exception {
		customerBean.setName("vigha");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
		customerBean.setAge(21);
		customerBean.setPanNo("ASDFG12345");
		accountBean.setBalance(100);
		accountBean.setCustomerBean(customerBean);
		boolean result = service.createAccount(accountBean);
		assertTrue(result);
		
	}
	
	  
	@Test
	public void testDeposit() throws Exception {
		customerBean.setName("Priya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
        customerBean.setAge(21);
        customerBean.setPanNo("ASDFG12345");
        accountBean.setBalance(1000);
        accountBean.setCustomerBean(customerBean);
		service.deposit(accountBean, 2000);
		
		assertEquals(3000, accountBean.getBalance(), 0);

	}
	@Test
	public void testDeposit1() throws Exception {
		customerBean.setName("Priya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
        customerBean.setAge(21);
        customerBean.setPanNo("ASDFG12345");
        accountBean.setBalance(5000);
        accountBean.setCustomerBean(customerBean);
		service.deposit(accountBean, 2000);
		assertNotEquals(3000, accountBean.getBalance(), 0);
	}
	@Test
	public void testWithdraw() throws Exception {
		customerBean.setName("Priya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
        customerBean.setAge(21);
        customerBean.setPanNo("ASDFG12345");
        accountBean.setBalance(5000);
        accountBean.setCustomerBean(customerBean);
		service.withdraw(accountBean, 2000);
		assertEquals(3000, accountBean.getBalance(), 0);

	}
	@Test
	public void testWithdraw1() throws Exception {
		customerBean.setName("Priya");
        customerBean.setPhNo(new BigInteger("9988776655"));
		customerBean.setEmailId("priyajoseph@gmail.com");
        customerBean.setAge(21);
        customerBean.setPanNo("ASDFG12345");
        accountBean.setBalance(7000);
        accountBean.setCustomerBean(customerBean);
		service.withdraw(accountBean, 3000);
		assertNotEquals(3000, accountBean.getBalance(), 0);

	}
	
	@Test
	public void testFundTransfer() throws Exception {
		customerBean.setName("vidya");
		customerBean.setPanNo("9988776655");
		customerBean.setEmailId("vidya@gmail.com");
		customerBean.setPanNo("EXR7890654");
		accountBean.setCustomerBean(customerBean);
		accountBean.setBalance(10000);
		CustomerBean custBean1 = new CustomerBean();
		AccountBean accBean1 = new AccountBean();
		custBean1.setName("John");
        custBean1.setPanNo("9988776688");
		custBean1.setEmailId("john@gmail.com");
		custBean1.setPanNo("KLM7890654");
        accBean1.setCustomerBean(customerBean);
		accBean1.setBalance(10000);
		service.fundTransfer(accountBean, accBean1, 5000);
		assertEquals(15000, accBean1.getBalance(), 0);
	}
	
	@Test
	public void testFundTransfer1() throws Exception {
		customerBean.setName("vidya");
		customerBean.setPanNo("9988776655");
		customerBean.setEmailId("vidya@gmail.com");
		customerBean.setPanNo("EXR7890654");
		accountBean.setCustomerBean(customerBean);
		accountBean.setBalance(15000);
		CustomerBean custBean1 = new CustomerBean();
		AccountBean accBean1 = new AccountBean();
		custBean1.setName("John");
        custBean1.setPanNo("9988776688");
		custBean1.setEmailId("john@gmail.com");
		custBean1.setPanNo("KLM7890654");
        accBean1.setCustomerBean(customerBean);
		accBean1.setBalance(15000);
		service.fundTransfer(accountBean, accBean1, 5000);
		assertNotEquals(25000, accBean1.getBalance(), 0);
	}

}

