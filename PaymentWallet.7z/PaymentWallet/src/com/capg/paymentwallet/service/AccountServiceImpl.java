package com.capg.paymentwallet.service;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.dao.AccountDaoImpl;
import com.capg.paymentwallet.dao.IAccountDao;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.exception.CustomerExceptionMessage;

public class AccountServiceImpl implements IAccountService{
	
	IAccountDao dao=new AccountDaoImpl();

	@Override
	public boolean createAccount(AccountBean accountBean) throws Exception {
		validateCustomer(accountBean);
	   return dao.createAccount(accountBean);
	}

	@Override
	public AccountBean findAccount(int accountId) throws Exception {
			return dao.findAccount(accountId);
		
	}

	@Override
	public boolean deposit(AccountBean accountBean, double depositAmount)
			throws Exception {
		return dao.deposit(accountBean, depositAmount);
	
		
	}

	@Override
	public boolean withdraw(AccountBean accountBean, double withdrawAmount)
			throws Exception {
		
		return dao.withdraw(accountBean, withdrawAmount);
		
	}

	@Override
	public boolean fundTransfer(AccountBean transferingAccountBean,
			AccountBean beneficiaryAccountBean, double transferAmount)
			throws Exception {
		
		
		
		
		/*boolean result1=dao.updateAccount(transferingAccountBean);
		boolean result2=dao.updateAccount(beneficiaryAccountBean);*/
		return dao.fundTransfer(transferingAccountBean, beneficiaryAccountBean, transferAmount);
		
	}
	
	public boolean validateCustomer(AccountBean accountBean) throws CustomerException{
		boolean isValid=true;
		if(accountBean.getCustomerBean().getName()==null || !(accountBean.getCustomerBean().getName().trim().matches("[A-Za-z]{4,12}"))){
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		
		
		if(accountBean.getCustomerBean().getEmailId()==null || !(accountBean.getCustomerBean().getEmailId().matches("[a-z0-9_.]+@[a-z]+\\.[a-zA-Z]{2,4}"))){
			throw new CustomerException(CustomerExceptionMessage.ERROR2);
		}
		
		if( !(accountBean.getCustomerBean().getAge()>18)){
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
			
		}
		
		if(accountBean.getCustomerBean().getPhNo()==null || !(accountBean.getCustomerBean().getPhNo().toString().matches("^[7-9][0-9]{9}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		
		if(accountBean.getCustomerBean().getPanNo()==null || !(accountBean.getCustomerBean().getPanNo().matches("[A-Z]{5}[0-9]{5}"))){
			throw new CustomerException(CustomerExceptionMessage.ERROR5);
		}
		if(!(accountBean.getBalance()>0)){
			throw new CustomerException(CustomerExceptionMessage.ERROR6);
		}
	
		
		
return isValid;
	
	
	}

}

